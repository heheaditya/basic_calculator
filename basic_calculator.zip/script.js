let display = document.getElementById("display");
let buttons = document.querySelectorAll("button");
let currentInput = "";
let operator = "";
let firstValue = null;

buttons.forEach(button => {
    button.addEventListener("click", () => {
        let value = button.textContent;

        if (!isNaN(value)) {
            currentInput += value;
            display.value = currentInput;
        } else if (value === "+" || value === "-") {
            firstValue = parseFloat(currentInput);
            operator = value;
            currentInput = "";
        } else if (value === "=") {
            if (firstValue !== null && currentInput !== "") {
                let secondValue = parseFloat(currentInput);
                let result = 0;
                if (operator === "+") result = firstValue + secondValue;
                else if (operator === "-") result = firstValue - secondValue;
                display.value = result;
                currentInput = "";
                firstValue = null;
                operator = "";
            }
        }
    });
});
